package com.example.appdraweractivitytest;

public class Tasks {

    public String taskName, taskDescription;

    public Tasks() {
    }
    public  Tasks(String taskName, String taskDescription)
    {
        this.taskName = taskName;
        this.taskDescription = taskDescription;
    }
}
